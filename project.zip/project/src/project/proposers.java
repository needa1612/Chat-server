package project;

import java.util.*;

public class proposers extends person
{	
	
	List<Integer> rankingList = new ArrayList<Integer>(mainGSAlgo.maxNoOfParticipants);
	
	//constructor
	public proposers(String personName, List<String> preferences)
	{
		super(personName, preferences);
		
		for(int i = 0; i < mainGSAlgo.maxNoOfParticipants ; i++)
			rankingList.add(0);
	}

	//getters and setters
	public String getName()
	{
		return super.name;
	}
	
	public List<String> getPrefList()
	{
		return super.prefList;
	}
	
	public List<Boolean> getPointer()
	{
		return super.pointer;
	}
	
	public List<Integer> getRankingList()
	{
		return rankingList;
	}
	
	public Boolean getPointerValueAtThisPosition(int position)
	{
		return super.pointer.get(position);
	}
	
	public void setName(String proposerName)
	{
		super.name = proposerName;
	}
	
	public void setPrefList(List<String> prefList)
	{
		super.prefList = prefList;
	}
	
	public void setPointer(int position, Boolean value)
	{
		super.pointer.set(position, value);
	}
	
	public int getReceiverPosition(String receiverName)
	{
		for(String eachReceiver : prefList)
		{
			if(eachReceiver.equalsIgnoreCase(receiverName))
				return prefList.indexOf(eachReceiver);
		}
		//if receiver not found in proposers pref list
		return -1;
	}
	
	//method to prepare ranking list
	public void prepareRankingList()
	{
		int index = 1;
		List<String> proposerPrefList = this.getPrefList();
		
		for(String eachReceiver : proposerPrefList)
		{
			rankingList.set((int)((eachReceiver).charAt(0)) - 65, index);
			index++;
		}
		
		//System.out.println(this.getName() + " : " + this.rankingList);
	}
}
