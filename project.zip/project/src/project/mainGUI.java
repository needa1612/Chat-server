package project;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.ScrollPane;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Scanner;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JSeparator;
import javax.swing.JTable;
import javax.swing.JTextPane;
import javax.swing.UIManager;
import javax.swing.border.LineBorder;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.text.DefaultHighlighter;
import javax.swing.text.Highlighter;

import java.awt.Panel;
import javax.swing.JLayeredPane;

public class mainGUI implements ActionListener
{
	static mainGSAlgo algo = new mainGSAlgo();
	
	static ArrayList<proposers> proposerList;
	static ArrayList<receivers> receiverList;
	static ArrayList<String> listOfProposers;
	static ArrayList<String> listOfReceivers;
	static Map<String, String> matches;
	
	static int globalFrameIncrementer;
	static int maxNoOfParticipants = 10;
	static ArrayList<frame> frames;
	
	//GUI components
	private JFrame frame;
	private JSeparator separator_1;
	private ScrollPane scrollPane;
	private JPanel panel_2;
	private JTextPane textPane, textPane_1, textPane_3;
	private JLabel lblFreeProposers, lblPseudocode, lblExecutionTrace, lblMen, lblWomen, lblMatchings;
	private JTextPane textPane_2, txtpnAssignEach;
	private JButton button1, button4, button7, button3, button5, btnExit, 
	    btnGenerateInputRandomly, btnRandomiseInput, btnSaveMatchesTo, btnNewButton;
	private int posPane_2 = 0;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) 
	{
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					mainGUI window = new mainGUI();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public mainGUI() 
	{
		//loading the main GUI
		initializeGUI();

	}
	
	private void initializeGUI() 
	{
		frame = new JFrame();
		frame.getContentPane().setBackground(Color.WHITE);
		frame.getContentPane().setForeground(UIManager.getColor("TabbedPane.foreground"));
		frame.getContentPane().setFont(new Font("Dialog", Font.PLAIN, 20));
		frame.setBounds(-7, 2, 2000, 1025);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		button1 = new JButton("|<<");
		button1.setFont(new Font("Dialog", Font.BOLD, 17));
		button1.setBounds(1068, 12, 63, 41);
		frame.getContentPane().add(button1);
		button1.setEnabled(false);
		
		button4 = new JButton("| |");
		button4.setFont(new Font("Dialog", Font.BOLD, 17));
		button4.setBounds(1218, 12, 57, 41);
		frame.getContentPane().add(button4);
		button4.setEnabled(false);
		
		button7 = new JButton(">>|");
		button7.setFont(new Font("Dialog", Font.BOLD, 17));
		button7.setBounds(1362, 12, 63, 41);
		frame.getContentPane().add(button7);
		button7.setEnabled(false);
		
		button3 = new JButton("<");
		button3.setFont(new Font("Dialog", Font.BOLD, 17));
		button3.setBounds(1146, 12, 57, 41);
		frame.getContentPane().add(button3);
		button3.setEnabled(false);
		
		button5 = new JButton(">");
		button5.setFont(new Font("Dialog", Font.BOLD, 17));
		button5.setBounds(1290, 12, 57, 41);
		frame.getContentPane().add(button5);
		button5.setEnabled(false);
		
		btnExit = new JButton("Exit");
		btnExit.setFont(new Font("Dialog", Font.BOLD, 17));
		btnExit.setBounds(1726, 12, 115, 41);
		frame.getContentPane().add(btnExit);
		
		separator_1 = new JSeparator();
		separator_1.setBounds(12, 65, 1888, 2);
		frame.getContentPane().add(separator_1);
		
		btnGenerateInputRandomly = new JButton("Generate input randomly");		
		btnGenerateInputRandomly.setFont(new Font("Dialog", Font.BOLD, 17));
		btnGenerateInputRandomly.setBounds(181, 12, 238, 41);
		frame.getContentPane().add(btnGenerateInputRandomly);
		btnGenerateInputRandomly.addActionListener(this);
		
		btnRandomiseInput = new JButton("Randomise input");
		btnRandomiseInput.setFont(new Font("Dialog", Font.BOLD, 17));
		btnRandomiseInput.setBounds(431, 12, 177, 41);
		frame.getContentPane().add(btnRandomiseInput);
		btnRandomiseInput.addActionListener(this);
		btnRandomiseInput.setEnabled(false);
		
		btnSaveMatchesTo = new JButton("Save matches to file");
		btnSaveMatchesTo.setFont(new Font("Dialog", Font.BOLD, 17));
		btnSaveMatchesTo.setBounds(620, 12, 200, 41);
		frame.getContentPane().add(btnSaveMatchesTo);
		btnSaveMatchesTo.setEnabled(false);
		
		scrollPane = new ScrollPane();
		scrollPane.setForeground(UIManager.getColor("TabbedPane.selected"));
		scrollPane.setBounds(1583, 145, 317, 814);
		frame.getContentPane().add(scrollPane);
		
		lblFreeProposers = new JLabel("FREE PROPOSERS");
		lblFreeProposers.setFont(new Font("Dialog", Font.BOLD, 20));
		lblFreeProposers.setBounds(123, 564, 192, 16);
		frame.getContentPane().add(lblFreeProposers);
		
		lblPseudocode = new JLabel("GALE SHAPLEY ALGORITHM");
		lblPseudocode.setFont(new Font("Dialog", Font.BOLD, 20));
		lblPseudocode.setBounds(112, 93, 283, 16);
		frame.getContentPane().add(lblPseudocode);
		
		lblMen = new JLabel("MEN");
		lblMen.setFont(new Font("Dialog", Font.BOLD, 20));
		lblMen.setBounds(604, 99, 55, 16);
		frame.getContentPane().add(lblMen);
		
		lblWomen = new JLabel("WOMEN");
		lblWomen.setFont(new Font("Dialog", Font.BOLD, 20));
		lblWomen.setBounds(1113, 93, 79, 16);
		frame.getContentPane().add(lblWomen);
		
		lblExecutionTrace = new JLabel("EXECUTION TRACE");
		lblExecutionTrace.setFont(new Font("Dialog", Font.BOLD, 20));
		lblExecutionTrace.setBounds(1649, 93, 192, 16);
		frame.getContentPane().add(lblExecutionTrace);
		
		textPane_1 = new JTextPane();
		textPane_1.setFont(new Font("Tahoma", Font.PLAIN, 25));
		textPane_1.setBorder(new LineBorder(new Color(0, 0, 0), 1, true));
		textPane_1.setBackground(UIManager.getColor("TabbedPane.selected"));
		textPane_1.setBounds(12, 597, 461, 119);
		frame.getContentPane().add(textPane_1);
		
		lblMatchings = new JLabel("MATCHINGS");
		lblMatchings.setFont(new Font("Dialog", Font.BOLD, 20));
		lblMatchings.setBounds(157, 732, 126, 16);
		frame.getContentPane().add(lblMatchings);
		
		textPane_2 = new JTextPane();
		textPane_2.setBorder(new LineBorder(new Color(0, 0, 0), 1, true));
		textPane_2.setBackground(UIManager.getColor("TabbedPane.selected"));
		textPane_2.setBounds(18, 764, 1534, 109);
		frame.getContentPane().add(textPane_2);
		
		btnNewButton = new JButton("Input from file");
		btnNewButton.setActionCommand("Input from file");
		btnNewButton.setFont(new Font("Dialog", Font.BOLD, 17));
		btnNewButton.setBounds(12, 12, 157, 41);
		frame.getContentPane().add(btnNewButton);
		btnNewButton.addActionListener(this);
		
		textPane_3 = new JTextPane();
		textPane_3.setBounds(1068, 131, 488, 614);
		frame.getContentPane().add(textPane_3);
		textPane_3.setFont(new Font("Tahoma", Font.PLAIN, 25));
		
		panel_2 = new JPanel();
		panel_2.setBackground(UIManager.getColor("TabbedPane.selected"));
		panel_2.setBounds(1, posPane_2, 493, 26);
		panel_2.setOpaque(false);
		panel_2.setBorder(new LineBorder(new Color(0, 0, 0), 1, true));
		panel_2.setLayout(null);
		panel_2.setVisible(true);
		
		txtpnAssignEach = new JTextPane();		
		txtpnAssignEach.setBounds(0, 0, 495, 406);
		txtpnAssignEach.setBorder(new LineBorder(new Color(0, 0, 0), 1, true));
		txtpnAssignEach.setBackground(UIManager.getColor("TabbedPane.selected"));
		txtpnAssignEach.setFont(new Font("Courier New", Font.PLAIN, 20));
		txtpnAssignEach.setText("\r\nassign each proposer to be free ;\r\nfor: (each free proposer m)\r\n{\r\n  w = first woman on m\u2019s list ;\r\n  m proposes to w ;\r\n  If(some man m' is already engaged to w)\r\n      assign m' to be free ;\r\n  assign m and w to be engaged ;\r\n  for:(each successor n of m on w\u2019s list)\r\n  {\r\n     delete (n , w) ;\r\n  }\r\n}");
		txtpnAssignEach.setOpaque(false);
		txtpnAssignEach.setVisible(true);
		
		JLayeredPane lpane = new JLayeredPane();
		lpane.setBounds(12, 125, 500, 406);
		frame.getContentPane().add(lpane);
		
		textPane = new JTextPane();
		textPane.setFont(new Font("Tahoma", Font.PLAIN, 25));
		textPane.setBounds(527, 131, 500, 614);
		frame.getContentPane().add(textPane);
		
		JTextPane textPane_4 = new JTextPane();
		textPane_4.setForeground(Color.RED);
		textPane_4.setBackground(new Color(0,0,0,0));
		textPane_4.setBorder(BorderFactory.createEmptyBorder());
		textPane_4.setBounds(896, 296, -164, 26);
		textPane_4.setOpaque(true);
		textPane.add(textPane_4);
		textPane_4.setVisible(true);		
		
		
		
		lpane.add(txtpnAssignEach, new Integer(0), 0);
		lpane.add(panel_2, new Integer(1), 0);
	}
	
	public void actionPerformed(ActionEvent actionEvent)
	{
		if(actionEvent.getSource() == btnNewButton)
		{						
			JFileChooser fileChooser = new JFileChooser();
			fileChooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
			fileChooser.setPreferredSize(new Dimension(800,600));
			FileNameExtensionFilter filter = new FileNameExtensionFilter("TEXT FILES", "txt", "text");
			fileChooser.setFileFilter(filter);

			if(fileChooser.showOpenDialog(null) == JFileChooser.APPROVE_OPTION)
			{
				String proposerInfo = "", receiverInfo = "", freeProposers = "";
				
				//get the file
				java.io.File file = fileChooser.getSelectedFile();
				
				try {
					algo.takeInputFromFile(new FileReader(file));
				} 
				catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				//take data to be displayed for proposers
				for(int i = 0 ; i < algo.proposerList.size() ; i++)
				{
					proposerInfo = proposerInfo + algo.proposerList.get(i).getName() + " : ";
					
					for(int j = 0 ; j < algo.proposerList.get(i).prefList.size() ; j++)
						proposerInfo = proposerInfo + algo.proposerList.get(i).prefList.get(j) + "   ";
					
					proposerInfo = proposerInfo + "\n\n";
				}
				
				//take data to be displayed for receivers
				for(int i = 0 ; i < algo.receiverList.size() ; i++)
				{
					receiverInfo = receiverInfo + algo.receiverList.get(i).getName() + " : ";
					
					for(int j = 0 ; j < algo.receiverList.get(i).prefList.size() ; j++)
						receiverInfo = receiverInfo + algo.receiverList.get(i).prefList.get(j) + "   ";
					
					receiverInfo = receiverInfo + "\n\n";
				}
				
				//take data to display free proposers
				for(int k = 0 ; k < algo.freeProposers.size() ; k++)
					freeProposers  = freeProposers + algo.freeProposers.get(k).getName() + "   ";

				//consistent input check
				if(!algo.consistentInputCheck())
				{	
					JOptionPane.showMessageDialog(null, "Inconsistent input! Input again or choose another file!", "Input error", JOptionPane.ERROR_MESSAGE);		
					
					//flush all values previously stored
					new mainGSAlgo();
					
					return;
				}
				else
				{					
					btnNewButton.setEnabled(false);
					btnGenerateInputRandomly.setEnabled(false);
					btnRandomiseInput.setEnabled(true);
					button4.setEnabled(true);	
					
					textPane.setText(proposerInfo);
					textPane_1.setText(freeProposers);
					textPane_3.setText(receiverInfo);
					panel_2.setBounds(1, posPane_2 + 26, 493, 26);
				}
			}
			
		}
		
		else if(actionEvent.getSource() == btnGenerateInputRandomly)
		{						
			String proposerInfo = "", receiverInfo = "", freeProposers = "";
			int noOfProposers = 0, noOfReceivers = 0;
			JOptionPane pane1 = new JOptionPane();
			JOptionPane pane2 = new JOptionPane();
			JDialog dialog = pane1.createDialog(null, "");
			
			try
			{
				do
				{
					noOfProposers = Integer.parseInt(pane1.showInputDialog(null, "Enter number of proposers")); 
					noOfReceivers = Integer.parseInt(pane2.showInputDialog(null, "Enter number of receivers")); 
					
					if(!((noOfProposers <= maxNoOfParticipants) && (noOfReceivers <= maxNoOfParticipants)))
						JOptionPane.showMessageDialog(null, "Number of proposers or receivers cannot be more than 10!", "Improper input", JOptionPane.ERROR_MESSAGE);

				}while( !((noOfProposers <= maxNoOfParticipants) && (noOfReceivers <= maxNoOfParticipants)));
			}
			catch(Exception e)
			{
				JOptionPane.showMessageDialog(null, "Enter a number between 1 and 10", "Improper input", JOptionPane.ERROR_MESSAGE);
				return;
			}
			
            try {
				algo.randomInputGeneration(noOfProposers, noOfReceivers);
			} catch (Exception e) {
				e.printStackTrace();
			}
			
			//take data to be displayed for proposers
			for(int i = 0 ; i < algo.proposerList.size() ; i++)
			{
				proposerInfo = proposerInfo + algo.proposerList.get(i).getName() + " : ";
				
				for(int j = 0 ; j < algo.proposerList.get(i).prefList.size() ; j++)
					proposerInfo = proposerInfo + algo.proposerList.get(i).prefList.get(j) + "   ";
				
				proposerInfo = proposerInfo + "\n\n";
			}
			
			//take data to be displayed for receivers
			for(int i = 0 ; i < algo.receiverList.size() ; i++)
			{
				receiverInfo = receiverInfo + algo.receiverList.get(i).getName() + " : ";
				
				for(int j = 0 ; j < algo.receiverList.get(i).prefList.size() ; j++)
					receiverInfo = receiverInfo + algo.receiverList.get(i).prefList.get(j) + "   ";
				
				receiverInfo = receiverInfo + "\n\n";
			}
			
			//take data to display free proposers
			for(int k = 0 ; k < algo.freeProposers.size() ; k++)
				freeProposers  = freeProposers + algo.freeProposers.get(k).getName() + "   ";
			
			textPane.setText(proposerInfo);
			textPane_1.setText(freeProposers);
			textPane_3.setText(receiverInfo);
			
			btnNewButton.setEnabled(false);
			btnGenerateInputRandomly.setEnabled(false);
			btnRandomiseInput.setEnabled(true);
			button4.setEnabled(true);
			panel_2.setBounds(1, posPane_2 + 26, 493, 26);
		}
		
		else if(actionEvent.getSource() == btnRandomiseInput)
		{
			String proposerInfo = "", freeProposers = "";
			
            algo.randomizeCurrentInput();
            
			//take data to be displayed for proposers
			for(int i = 0 ; i < algo.proposerList.size() ; i++)
			{
				proposerInfo = proposerInfo + algo.proposerList.get(i).getName() + " : ";
				
				for(int j = 0 ; j < algo.proposerList.get(i).prefList.size() ; j++)
					proposerInfo = proposerInfo + algo.proposerList.get(i).prefList.get(j) + "   ";
				
				proposerInfo = proposerInfo + "\n\n";
			}
            
			//take data to display free proposers
			for(int k = 0 ; k < algo.freeProposers.size() ; k++)
				freeProposers  = freeProposers + algo.freeProposers.get(k).getName() + "   ";
			
			textPane.setText(proposerInfo);
			textPane_1.setText(freeProposers);
		}
		
		else if(actionEvent.getSource() == button4)
		{
			//algo.doMatching();
			
//			Graphics g = new Graphics();
//			g.setColor(UIManager.getColor("TabbedPane.selected"));
//			g.fillRect(10, 10, 100, 100);
//			g.setColor(UIManager.getColor("TabbedPane.selected"));
//			g.drawRect(10, 10, 100, 100);
			  }

		}
//	}
	
	//return receiver object from receiver name
	public static receivers contains(String name)
	{
		for(receivers eachReceiver : receiverList)
		{
			if(eachReceiver.getName().equalsIgnoreCase(name))
				return eachReceiver;
		}
		//else no receiver with this name - return null
		return null;
		
	}
	
	public static void display()
	{
		String proposerInfo = "", receiverInfo = "", freeProposers = "", matchingsInfo = "", traceInfo = "";


		
	}
}

