package project;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.FlowLayout;

import javax.swing.BorderFactory;
import javax.swing.JApplet;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.OverlayLayout;
import java.awt.Component;
import java.awt.Container;
import java.awt.Font;

public class GUItrial extends JApplet{

	//private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					GUItrial window = new GUItrial();
				//	window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public GUItrial() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
        Container Cntnr = getContentPane();
        JPanel Pnl = new JPanel();
        Pnl.setLayout(new OverlayLayout(Pnl));
        Pnl.setBackground(Color.white);
        Pnl.setBorder(BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder(),"OverLays"));
        JTextField Txt1 = new JTextField("Text One");
        JTextField Txt2 = new JTextField("Text Two");
        Txt1.setMinimumSize(new Dimension(35,35));
        Txt2.setMinimumSize(new Dimension(35,35));
        Txt1.setPreferredSize(new Dimension(110,110));
        Txt2.setPreferredSize(new Dimension(110,110));
        Txt1.setMaximumSize(new Dimension(125,125));
        Txt2.setMaximumSize(new Dimension(125,125));
        Txt1.setAlignmentX(0.3f);
        Txt1.setAlignmentY(0.3f);
        Txt2.setAlignmentX(0.9f);
        Txt2.setAlignmentY(0.9f);
        Pnl.add(Txt1);
        Pnl.add(Txt2);
        Cntnr.setLayout(new FlowLayout());
        Cntnr.add(Pnl);
    }
	

}
