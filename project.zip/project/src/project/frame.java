package project;

import java.util.*;

public class frame 
{
	int posOfProposerCircle;
	int posOfReceiverCircle;

	String proposerUnderConsideration;
	String receiverUnderConsideration;
	
	String[][] proposerCrossMatrix = new String[mainGSAlgo.maxNoOfParticipants][mainGSAlgo.maxNoOfParticipants];
	String[][] receiverCrossMatrix = new String[mainGSAlgo.maxNoOfParticipants][mainGSAlgo.maxNoOfParticipants];
	
	List<String> freeProposers;
	List<String> executionTrace;
	List<String> matchings;

	//default constructor
	public frame()
	{
		posOfProposerCircle = 0;
		posOfReceiverCircle = 0;
		
		proposerUnderConsideration = "";
		receiverUnderConsideration = "";
		
		for(int i = 0; i < mainGSAlgo.listOfProposers.size() ; i++)
			for(int j = 0; j < mainGSAlgo.proposerList.get(i).getPrefList().size() ; j++)
				proposerCrossMatrix[i][j] = mainGSAlgo.proposerList.get(i).getPrefList().get(j);
		
		for(int i = 0; i < mainGSAlgo.listOfReceivers.size() ; i++)
			for(int j = 0; j < mainGSAlgo.receiverList.get(i).getPrefList().size() ; j++)
				receiverCrossMatrix[i][j] = mainGSAlgo.receiverList.get(i).getPrefList().get(j);
		
		freeProposers = new ArrayList<String>();
		executionTrace = new ArrayList<String>();
		matchings = new ArrayList<String>();
	}
	
	//set details for this frame
	public void prepareFrame(String currentProposer, String currentReceiver, int posInProposerPreferences, int posInReceiverPreferences,  String freeProposer, String trace, String matches)
	{		
		this.proposerUnderConsideration = currentProposer;
		this.receiverUnderConsideration = currentReceiver;
		
		this.posOfProposerCircle = posInProposerPreferences;
		this.posOfReceiverCircle = posInReceiverPreferences;
		
		//set the element to X at the specified position
		System.out.println("current proposer = " + currentProposer);
		this.proposerCrossMatrix[Integer.parseInt(currentProposer)-1][posOfProposerCircle] = "X";
		this.receiverCrossMatrix[(int)(currentReceiver).charAt(0) - 65][posOfReceiverCircle] = "X";
		
		this.freeProposers.add(freeProposer);
		this.executionTrace.add(trace);
		this.matchings.add(trace);
		
		//display frame
		
		System.out.println(freeProposer);
		System.out.println(trace);
		System.out.println(matches);

		System.out.println("-------------------------------------");
		System.out.println("Proposer matrix : ");
		for(int i = 0; i < mainGSAlgo.listOfProposers.size() ; i++)
		{
			System.out.println();
			for(int j = 0; j < mainGSAlgo.proposerList.get(i).getPrefList().size() ; j++)
				System.out.print(" " + proposerCrossMatrix[i][j]);
		}

		System.out.println();
		System.out.println("Receiver matrix : ");
		for(int i = 0; i < mainGSAlgo.listOfReceivers.size() ; i++)
		{
			System.out.println();
			for(int j = 0; j < mainGSAlgo.receiverList.get(i).getPrefList().size() ; j++)
				System.out.print(" " + receiverCrossMatrix[i][j]);
		}
		System.out.println();
		System.out.println("-------------------------------------");

	}
	
	//display frame details on console
	/*public static void displayFrame()
	{
		System.out.println("-------------------------------------");
		System.out.println("Proposer matrix : ");
		for(int i = 0; i < 10 ; i++)
		{
			System.out.println();
			for(int j = 0; j < 10 ; j++)
				System.out.print(" " + proposerCrossMatrix[i][j]);
		}
		
		System.out.println();
		System.out.println("Receiver matrix : ");
		for(int i = 0; i < 10 ; i++)
		{
			System.out.println();
			for(int j = 0; j < 10 ; j++)
				System.out.print(" " + receiverCrossMatrix[i][j]);
		}
		System.out.println();
		System.out.println("-------------------------------------");
	}*/

}
