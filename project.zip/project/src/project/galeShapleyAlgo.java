package project;

import java.util.*;
import java.io.*;


public class galeShapleyAlgo
{

	static List<String> proposer = null;
	static List<String> receiver = null;
	static Map<String, List<String>> proposerPrefList = null;
	static Map<String, List<String>> receiverPrefList = null;
	static int[][] rankingList = null;
	static Map<String, String> matches = null;

	//constructor
	public galeShapleyAlgo() throws IOException
	{		
		// initialialization
		proposer = new ArrayList<String>();
		receiver = new ArrayList<String>();
		proposerPrefList = new HashMap<String, List<String>>();
		receiverPrefList = new HashMap<String, List<String>>();
		rankingList = new int[11][11];

		matches =  new TreeMap<String, String>();
	}

	//MAIN
	public static void main(String[] args) throws Exception 
	{		
		new galeShapleyAlgo();

		int choice = 0;

		System.out.println("Enter 1 - take input from file\n       2 - randomly generate input");
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

		do
		{
			choice = Integer.parseInt(br.readLine());
			System.out.println("Choice = " + choice);

			if(choice == 1)
			{
				takeInputFromFile();
				break;
			}
			else if(choice == 2)
			{
				randomInputGeneration();
				break;
			}
			else
				System.out.println("Invalid choice! Enter again!");

		}while (choice != 1 || choice != 2);


		if(!consistentInputCheck())
		{
			System.out.println("Inconsistent input!");
			System.exit(0);
		}
		else
			System.out.println("Consistent input!");


		prepareRankingList();

		System.out.println("Randomize input? (yes/no)");
		String ch = null;
		do
		{
			ch = br.readLine();
			if(ch.equalsIgnoreCase("yes"))
			{
				randomizeCurrentInput();
				break;
			}
			else if (ch.equalsIgnoreCase("no")) break;
			else System.out.println("Invalid choice! Enter again");
		}while( ! ((ch.equalsIgnoreCase("yes") || (ch.equalsIgnoreCase("no")))));	

		matches = doMatching();

		// print matches
		System.out.println("\n-----------------------------------------");
		System.out.println("               MATCHINGS ");
		System.out.println("-----------------------------------------");
		for(String eachReceiver : receiver)
			System.out.println(eachReceiver + " " + matches.get(eachReceiver));
		System.out.println("-----------------------------------------\n");
		
		if(checkStability())
			System.out.println("\nStable");
		else
			System.out.println("\nUnstable");

		writeMatchingsToAFile();

	}

	public static void takeInputFromFile() throws Exception
	{		
		BufferedReader fileReader = null;
		//taking input from file - read proposer and receiver preferences
		try {
			String currentLineString = null;
			String[] currentLineArray = null;
			fileReader = new BufferedReader(new FileReader("test1-list.txt"));

			// store these preferences in data structures

			//PROPOSER
			while(!((currentLineString = fileReader.readLine()).equals(""))) 
			{
				currentLineArray = currentLineString.split(" ");
				int numberOfPeople = currentLineArray.length - 1;
				String ranker = currentLineArray[0];

				if( !(proposer.contains(ranker)))
				{
					List<String> prefList = Arrays.asList(Arrays.copyOfRange(currentLineArray, 1, currentLineArray.length));
					proposer.add(ranker);
					proposerPrefList.put(ranker, prefList);
				}
			}

			//RECEIVER
			while((currentLineString = fileReader.readLine()) != null) 
			{
				currentLineArray = currentLineString.split(" ");
				int numberOfPeople = currentLineArray.length - 1;
				String ranker = currentLineArray[0];

				if( ! (receiver.contains(ranker)))
				{
					List<String> prefList = Arrays.asList(Arrays.copyOfRange(currentLineArray, 1, currentLineArray.length));
					receiver.add(ranker);
					receiverPrefList.put(ranker, prefList);
				}
			}

			//printing both proposer and receiver preferences read
			System.out.println("Proposers");
			for(String proposer : proposer)
				System.out.println(proposer + " : " + proposerPrefList.get(proposer));
			System.out.println("Receivers");
			for(String receiver : receiver)
				System.out.println(receiver + " : " + receiverPrefList.get(receiver));



		} 
		catch (IOException e) 
		{
			e.printStackTrace();
		} 

		fileReader.close();		
	}

	public static boolean consistentInputCheck()
	{
		int proposerPrefCount = 0 , receiverPrefCount = 0;

		for(String proposer : proposer)
		{
			List<String> currentProposerPrefList = proposerPrefList.get(proposer);

			for(String receiver : currentProposerPrefList)
			{
			    proposerPrefCount++;
			    
				if( receiverPrefList.get(receiver).contains(proposer)) ;
				else 
					return false;
			}
		}

		for(String receiver : receiver)
		{
			List<String> currentReceiverPrefList = receiverPrefList.get(receiver);
				receiverPrefCount += currentReceiverPrefList.size();
		}
		
		if(proposerPrefCount == receiverPrefCount)
			return true;
		else
			return false;
	}


	//prepare ranking list for proposer
	public static void prepareRankingList() 
	{
		int receiverIndex = 1;		

		for(int i = 0; i <= receiver.size(); i++)
			for(int j = 0; j <= proposer.size(); j++)
				rankingList[i][j] = 0;

		for(String eachReceiver : receiver)
		{
			int k = 1;
			List<String> receiverPreferences =  receiverPrefList.get(eachReceiver);

			//storing ASCII value of receiver in their ranking list at 0th position
			rankingList[receiverIndex][0] = ((int)eachReceiver.charAt(0));

			for(String proposer : receiverPreferences)
			{
				rankingList[receiverIndex][Integer.parseInt(proposer)] = k;
				k++;
			}
			receiverIndex++;
		}
	}

	public static void randomizeCurrentInput()
	{
		Random rand = new Random();

		for( int i = 0; i < proposer.size(); i++ )
		{
			int position = rand.nextInt(proposer.size());

			//swap ith proposer with randomly generated proposer
			String tempProposer = proposer.get(position);
			proposer.set(position, proposer.get(i));
			proposer.set(i, tempProposer);
		}
		System.out.println("Randomised proposer list : " + proposer);

		//printing both proposer and receiver preferences read
		System.out.println("Proposers");
		for(String proposer : proposer)
			System.out.println(proposer + " : " + proposerPrefList.get(proposer));
		System.out.println("Receivers");
		for(String receiver : receiver)
			System.out.println(receiver + " : " + receiverPrefList.get(receiver));
	}

	
	//ASSUMPTION : this function always generates consistent input
	public static void randomInputGeneration() throws Exception
	{
		Random rand = new Random();

		System.out.println("Enter no. of proposers and receivers : ");
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int noOfProposers = 0;
		int noOfReceivers = 0;

		do
		{
			noOfProposers = Integer.parseInt(br.readLine());
			noOfReceivers = Integer.parseInt(br.readLine());

			if(!((noOfProposers <= 10) && (noOfReceivers <= 10)))
				System.out.println("No. of proposers and receivers cannot be more than 10! Enter again!");

		}while( !((noOfProposers <= 10) && (noOfReceivers <= 10)));

		System.out.println("Preparing proposer preference list");

		//preparing proposer preference list
		for(int i = 0; i < noOfProposers; i++)
		{
			int noOfPrefernces = rand.nextInt(noOfReceivers);
			List<String> preferences = new ArrayList<String>();

			for(int j = 0 ; j < noOfPrefernces ; j++)
			{
				String generatedReceiver = Character.toString((char)(rand.nextInt(noOfReceivers) + 65));
				if( ! (preferences.contains(generatedReceiver)))
					preferences.add(generatedReceiver);

				if( ! (receiver.contains(generatedReceiver)))
					receiver.add(generatedReceiver);
			}

			String newProposer = "" + (i+1);
			proposer.add(newProposer);
			proposerPrefList.put(newProposer, preferences);

			System.out.println(newProposer + " : " + proposerPrefList.get(newProposer));
		}

		System.out.println("Preparing receiver preference list");

		//preparing receiver preference list

		for(String eachReceiver : receiver)
		{
			List<String> preferences = new ArrayList<String>();

			for(String eachProposer : proposer)
			{
				if((proposerPrefList.get(eachProposer)).contains(eachReceiver))
					preferences.add(eachProposer);
			}

			receiverPrefList.put(eachReceiver, preferences);
			System.out.println(eachReceiver + " : " + receiverPrefList.get(eachReceiver)); 

		}
	}


	public static Map<String, String> doMatching()
	{
		Map<String, String> matches = new TreeMap<String, String>();

		// freeProposers is the list of all proposers who are not matched, initially contains all proposers
		List<String> freeProposers = new LinkedList<String>();
		freeProposers.addAll(proposer);

		System.out.println("List of free proposers : " + freeProposers);

		// loop until no more free proposers
		while(!freeProposers.isEmpty()) 
		{
			String currentProposer = freeProposers.remove(0);  //stack functioning
			List<String> currentProposerPrefers = proposerPrefList.get(currentProposer);

			for (String receiver : currentProposerPrefers) 
			{
				System.out.println(currentProposer + " proposes " + receiver);

				//for each receiver, obtain his/her preference list
				List<String> currentReceiverPrefList = receiverPrefList.get(receiver);
				
	/*			//for each proposer after the one who is proposing, delete this proposer from the receiver preference list
				for(int i = currentReceiverPrefList.indexOf(currentProposer) ; i < currentReceiverPrefList.size() ; i++)
				{
					String proposerToBeDeleted = currentReceiverPrefList.get(i);
					List<String> proposerToBeDeletedPrefList = new ArrayList<String>();
				    proposerToBeDeletedPrefList	= proposerPrefList.get(proposerToBeDeleted);
					proposerToBeDeletedPrefList.remove(receiver);				
					
					proposerPrefList.put(proposerToBeDeleted, proposerToBeDeletedPrefList); 
				}*/
				
				
					//delete proposers from receiverPrefList
					currentReceiverPrefList = currentReceiverPrefList.subList(0, currentReceiverPrefList.indexOf(currentProposer)+1);
					receiverPrefList.put(receiver, currentReceiverPrefList);

					//once you find the required proposer in the receiverPrefList - match it!
					System.out.println(receiver + " matched to " + currentProposer);
					matches.put(receiver, currentProposer); 			
					break;
				

			}
		}

		return matches;
	}

	public static boolean checkStability() throws Exception
	{
		Map<String, String> invertedMatches = new HashMap<String, String>();
		for(Map.Entry<String, String> entry: matches.entrySet()) 
			invertedMatches.put(entry.getValue(), entry.getKey());

		for(proposers eachProposer : proposerList)
		{
			int index = 0;

			//stability check done only for those proposers who are matched
			if(matches.containsValue(eachProposer.getName()))
			{
				List<String> currentProposerPrefList = eachProposer.getPrefList();

				//for each women in proposer's list such that this proposer prefers this women over the matched one
				while(!(currentProposerPrefList.get(index).equalsIgnoreCase(matches.get(eachProposer.getName()))))
				{
					String matchedProposer = invertedMatches.get(currentProposerPrefList.get(index));

					//if receiver prefers current proposer to the matched one - unstable matching!!
					if((rankingList[(int)(currentProposerPrefList.get(index)).charAt(0) - 64][Integer.parseInt(eachProposer)] < rankingList[(int)(currentProposerPrefList.get(index)).charAt(0) - 64][Integer.parseInt(matchedProposer)]) 
							&& (rankingList[(int)(currentProposerPrefList.get(index)).charAt(0) - 64][Integer.parseInt(eachProposer)] != 0) )
						return false;
					else
						index++;
				}
			}
		}

		return true;
	}

	public static void writeMatchingsToAFile() throws Exception
	{

		FileWriter fw = new FileWriter("Matchings.txt");
		BufferedWriter bw = new BufferedWriter(fw);

		try {
			bw.write(" Men  Women");
			bw.newLine();

			for(String eachReceiver : receiver)
			{
				bw.append("  " + eachReceiver + "    " + matches.get(eachReceiver));
				bw.newLine();
			}

		} catch (IOException e) {e.printStackTrace();} 
		finally 
		{
			bw.close();
			fw.close();
		}
	}

}
