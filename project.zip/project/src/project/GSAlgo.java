package project;
import java.awt.EventQueue;
import java.awt.Toolkit;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.awt.event.ActionEvent;
import javax.swing.JTextArea;
import java.awt.Font;
import javax.swing.JTextPane;
import javax.swing.JSeparator;
import java.awt.TextField;
import javax.swing.JScrollBar;
import java.awt.ScrollPane;
import javax.swing.JLabel;
import java.awt.Color;
import java.awt.SystemColor;
import javax.swing.UIManager;
import javax.swing.border.LineBorder;
import javax.swing.border.MatteBorder;
import javax.swing.border.EtchedBorder;
import javax.swing.JTable;
import java.awt.Component;
import javax.swing.JCheckBoxMenuItem;
import javax.swing.JFileChooser;

public class GSAlgo {

	private JFrame frame;
	private JTextPane textPane_2;
	private JTable table;
	private JTable table_1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					GSAlgo window = new GSAlgo();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public GSAlgo() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(Color.WHITE);
		frame.getContentPane().setForeground(Color.WHITE);
		frame.getContentPane().setFont(new Font("Dialog", Font.PLAIN, 20));
		frame.setBounds(-7, 2, 2000, 1025);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JButton button1 = new JButton("|<<");
		button1.setFont(new Font("Dialog", Font.BOLD, 17));
		button1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			}
		});
		button1.setBounds(1068, 12, 63, 41);
		frame.getContentPane().add(button1);
		
		JButton button2 = new JButton("<<");
		button2.setFont(new Font("Dialog", Font.BOLD, 17));
		button2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			}
		});
		button2.setBounds(1157, 12, 57, 41);
		frame.getContentPane().add(button2);
		
		JButton button4 = new JButton("| |");
		button4.setFont(new Font("Dialog", Font.BOLD, 17));
		button4.setBounds(1323, 12, 57, 41);
		frame.getContentPane().add(button4);
		
		JButton button6 = new JButton(">>");
		button6.setFont(new Font("Dialog", Font.BOLD, 17));
		button6.setBounds(1486, 12, 57, 41);
		frame.getContentPane().add(button6);
		
		JButton button7 = new JButton(">>|");
		button7.setFont(new Font("Dialog", Font.BOLD, 17));
		button7.setBounds(1570, 12, 63, 41);
		frame.getContentPane().add(button7);
		
		JButton button3 = new JButton("<");
		button3.setFont(new Font("Dialog", Font.BOLD, 17));
		button3.setBounds(1237, 12, 57, 41);
		frame.getContentPane().add(button3);
		
		JButton button5 = new JButton(">");
		button5.setFont(new Font("Dialog", Font.BOLD, 17));
		button5.setBounds(1406, 12, 57, 41);
		frame.getContentPane().add(button5);
		
		JButton btnExit = new JButton("Exit");
		btnExit.setFont(new Font("Dialog", Font.BOLD, 17));
		btnExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
			}
		});
		btnExit.setBounds(1726, 12, 115, 41);
		frame.getContentPane().add(btnExit);
		
		JTextPane txtpnAssignEach = new JTextPane();
		txtpnAssignEach.setBorder(new LineBorder(new Color(0, 0, 0), 1, true));
		txtpnAssignEach.setBackground(UIManager.getColor("TabbedPane.contentAreaColor"));
		txtpnAssignEach.setFont(new Font("Dialog", Font.PLAIN, 20));
		txtpnAssignEach.setText("1. Assign each person to be free\r\n2. For: each man m in the list of free proposers\r\n3. {\r\n4.    w: first woman on m\u2019s list\r\n5.    m proposes w\r\n6.    If some man p is already engaged to w, \r\n         then assign p to be free\r\n7.    Assign m and w to be engaged (to each other)\r\n8.    For: each successor n of m on w\u2019s list\r\n9.     {\r\n10.      Delete w from n\u2019s list\r\n11.   }\r\n12. }\r\n13. end\r\n");
		txtpnAssignEach.setBounds(12, 131, 461, 396);
		frame.getContentPane().add(txtpnAssignEach);
		
		JSeparator separator_1 = new JSeparator();
		separator_1.setBounds(12, 65, 1888, 2);
		frame.getContentPane().add(separator_1);
		
		JButton btnGenerateInputRandomly = new JButton("Generate input randomly");
		btnGenerateInputRandomly.setFont(new Font("Dialog", Font.BOLD, 17));
		btnGenerateInputRandomly.setBounds(181, 12, 238, 41);
		frame.getContentPane().add(btnGenerateInputRandomly);
		
		JButton btnRandomiseInput = new JButton("Randomise input");
		btnRandomiseInput.setFont(new Font("Dialog", Font.BOLD, 17));
		btnRandomiseInput.setBounds(431, 12, 177, 41);
		frame.getContentPane().add(btnRandomiseInput);
		
		JButton btnSaveMatchesTo = new JButton("Save matches to file");
		btnSaveMatchesTo.setFont(new Font("Dialog", Font.BOLD, 17));
		btnSaveMatchesTo.setBounds(620, 12, 200, 41);
		frame.getContentPane().add(btnSaveMatchesTo);
		
		ScrollPane scrollPane = new ScrollPane();
		scrollPane.setForeground(UIManager.getColor("TabbedPane.selected"));
		scrollPane.setBounds(1583, 145, 317, 814);
		frame.getContentPane().add(scrollPane);
		
		JLabel lblFreeProposers = new JLabel("FREE PROPOSERS");
		lblFreeProposers.setFont(new Font("Dialog", Font.BOLD, 20));
		lblFreeProposers.setBounds(123, 564, 192, 16);
		frame.getContentPane().add(lblFreeProposers);
		
		JLabel lblPseudocode = new JLabel("PSEUDOCODE");
		lblPseudocode.setFont(new Font("Dialog", Font.BOLD, 20));
		lblPseudocode.setBounds(170, 93, 145, 16);
		frame.getContentPane().add(lblPseudocode);
		
		JLabel lblMen = new JLabel("MEN");
		lblMen.setFont(new Font("Dialog", Font.BOLD, 20));
		lblMen.setBounds(730, 93, 55, 16);
		frame.getContentPane().add(lblMen);
		
		JLabel lblWomen = new JLabel("WOMEN");
		lblWomen.setFont(new Font("Dialog", Font.BOLD, 20));
		lblWomen.setBounds(1272, 93, 79, 16);
		frame.getContentPane().add(lblWomen);
		
		JLabel lblExecutionTrace = new JLabel("EXECUTION TRACE");
		lblExecutionTrace.setFont(new Font("Dialog", Font.BOLD, 20));
		lblExecutionTrace.setBounds(1649, 93, 192, 16);
		frame.getContentPane().add(lblExecutionTrace);
		
		JTextPane textPane_1 = new JTextPane();
		textPane_1.setBorder(new LineBorder(new Color(0, 0, 0), 1, true));
		textPane_1.setBackground(UIManager.getColor("TabbedPane.selected"));
		textPane_1.setBounds(12, 597, 461, 46);
		frame.getContentPane().add(textPane_1);
		
		JLabel lblMatchings = new JLabel("MATCHINGS");
		lblMatchings.setFont(new Font("Dialog", Font.BOLD, 20));
		lblMatchings.setBounds(162, 675, 126, 16);
		frame.getContentPane().add(lblMatchings);
		
		textPane_2 = new JTextPane();
		textPane_2.setBorder(new LineBorder(new Color(0, 0, 0), 1, true));
		textPane_2.setBackground(UIManager.getColor("TabbedPane.selected"));
		textPane_2.setBounds(12, 708, 1559, 67);
		frame.getContentPane().add(textPane_2);
		
		JPanel panel = new JPanel();
		panel.setBounds(507, 142, 506, 534);
		frame.getContentPane().add(panel);
		panel.setLayout(null);
		
		table = new JTable();
		table.setFont(new Font("Dialog", Font.PLAIN, 20));
		table.setBounds(0, 0, 506, 534);
		panel.add(table);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBounds(1037, 140, 530, 536);
		frame.getContentPane().add(panel_1);
		panel_1.setLayout(null);
		
		table_1 = new JTable();
		table_1.setBounds(0, 0, 530, 536);
		panel_1.add(table_1);
		
		JButton btnNewButton = new JButton("Input from file");
		btnNewButton.setActionCommand("Input from file");
		btnNewButton.setFont(new Font("Dialog", Font.BOLD, 17));
		btnNewButton.setBounds(12, 12, 157, 41);
		frame.getContentPane().add(btnNewButton);
		
		btnNewButton.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent arg0)
			{
				JFileChooser fileChooser = new JFileChooser();
				
				if(fileChooser.showOpenDialog(null) == JFileChooser.APPROVE_OPTION)
				{
					//get the file
					java.io.File file = fileChooser.getSelectedFile();
					
					//create a scanner for the file
					Scanner input = null;
					try {
						input = new Scanner(file);
					} catch (FileNotFoundException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					
					//read text from file
					while(input.hasNext())
					{
						
					}
					
					
				}
			}
		});
	}
	
}
