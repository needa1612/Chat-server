package project;

import java.util.*;
import java.io.*;
import java.io.IOException;


public class StableMatchingWithRankingList 
{
	
	static List<String> proposer = null;
	static List<String> receiver = null;
	static Map<String, List<String>> proposerRanking = null;
	static Map<String, List<String>> receiverRanking = null;
	static int[][] receiverRankingList = null;
	static Map<String, String> matches = null;
	
	//constructor
	public StableMatchingWithRankingList() throws IOException
	{		
		// initialialization
		proposer = new ArrayList<String>();
		receiver = new ArrayList<String>();
		proposerRanking = new HashMap<String, List<String>>();
		receiverRanking = new HashMap<String, List<String>>();
		receiverRankingList = new int[11][11];
		
		matches =  new TreeMap<String, String>();
	}
	
	//MAIN
	public static void main(String[] args) throws Exception 
	{		
		new StableMatchingWithRankingList();
		
		takeInputFromFile();
		
		prepareRankingList();
		
		matches = doMatching();
		
		// print matches
		for(String eachReceiver : receiver)
            System.out.println(eachReceiver + " " + matches.get(eachReceiver));
		
		if(checkStability())
			System.out.println("\nStable");
		else
			System.out.println("\nUnstable");
		
		writeMatchingsToAFile();
 	
	}
	
	private static Map<String, String> doMatching()
	{
		Map<String, String> matches = new TreeMap<String, String>();
		
		// freeProposers is the list of all proposers who are not matched, initially contains all proposers
		List<String> freeProposers = new LinkedList<String>();
		freeProposers.addAll(proposer);
		
		// loop until no more free proposers
		while(!freeProposers.isEmpty()) 
		{
			String currentProposer = freeProposers.remove(0);  //stack functioning
			List<String> currentProposerPrefers = proposerRanking.get(currentProposer);
			
			//System.out.println(currentProposer + "'s reduced preference list : " + currentProposerPrefers);
			
			for (String receiver : currentProposerPrefers) 
			{
				
				//removing those receivers from proposer preference list who have already been proposed
				currentProposerPrefers = currentProposerPrefers.subList((currentProposerPrefers.indexOf(receiver))+1, currentProposerPrefers.size());
				proposerRanking.put(currentProposer, currentProposerPrefers);
				//System.out.println(currentProposer + "'s preference list : " + proposerRanking.get(currentProposer));			
				
				//for each receiver, obtain his/her preference list
				List<String> currentReceiverPrefList = receiverRanking.get(receiver);
				
				if(matches.get(receiver) == null && receiverRankingList[(int)receiver.charAt(0) - 64][Integer.parseInt(currentProposer)] != 0) 
				{ 
					//this receiver is free (not matched) - match these two
					matches.put(receiver, currentProposer);     
					//System.out.println("Not matched - Pair made : (" + receiver + " , " + currentProposer + ")");
					
					//delete all proposers after the matched one now
	                //from the position of current proposer in the receiver's preference list, delete all proposers after that (extended Gale Shapley)
	                
					currentReceiverPrefList = currentReceiverPrefList.subList(0, currentReceiverPrefList.indexOf(currentProposer)+1);
	                receiverRanking.put(receiver, currentReceiverPrefList);
	                
	                //System.out.println("Revised preferences for " + receiver + " are " + receiverRanking.get(receiver));
	                
	                //revise receiver ranking list after deletions
	                prepareRankingList();
					
					break;
				}
				else if(matches.get(receiver) != null)
				{
					//get the proposer it is matched on to previously
					 String matchedProposer = matches.get(receiver);
					 
					 //System.out.println(receiver + " matched to " + matchedProposer);
					 
					 if((receiverRankingList[(int)receiver.charAt(0) - 64][Integer.parseInt(currentProposer)] < receiverRankingList[(int)receiver.charAt(0) - 64][Integer.parseInt(matchedProposer)]) &&
						 (receiverRankingList[(int)receiver.charAt(0) - 64][Integer.parseInt(currentProposer)] != 0))
					 {
						 matches.put(receiver,currentProposer);
						 matches.remove(matchedProposer);
						 
						 //System.out.print(" but " + receiver + " prefers " + currentProposer + " over " + matchedProposer);
						 //System.out.println(". So new match : (" + receiver + " , " + currentProposer + ")");
						 
						 freeProposers.add(matchedProposer);
						 
						 //System.out.println(matchedProposer + " becomes free now");
						 
						//delete all proposers after the matched one now
			            //from the position of current proposer in the receiver's preference list, delete all proposers after that (extended Gale Shapley)
			                
							currentReceiverPrefList = currentReceiverPrefList.subList(0, currentReceiverPrefList.indexOf(currentProposer)+1);
			                receiverRanking.put(receiver, currentReceiverPrefList);
			                
			                //System.out.println("Revised preferences for " + receiver + " are " + receiverRanking.get(receiver));
			                
			                //revise receiver ranking list after deletions
			                prepareRankingList();
						 
						 
					 }
					 else
					 {
						 freeProposers.add(currentProposer);
						 //System.out.println(receiver + " prefers " + matchedProposer + " (matched proposer) over " + currentProposer + ". So no change.");
					     //System.out.println(currentProposer + " gets added to free stack now.");
					 }
					break; 
				
				}
			}
		}
		
		return matches;
	}

	
	private static void takeInputFromFile() throws Exception
	{
		BufferedReader fileReader1 = null,fileReader2 = null;
		
		//taking input from file - read proposer and receiver preferences
		try {
			String currentLineString = null;
			String[] currentLineArray = null;
		    fileReader1 = new BufferedReader(new FileReader("men-incomplete list.txt"));
		    fileReader2 = new BufferedReader(new FileReader("women-incomplete list.txt"));
		
		// store these preferences in data structures
		
		//PROPOSER
		while((currentLineString = fileReader1.readLine()) != null) 
		{
			currentLineArray = currentLineString.split(" ");
			int numberOfPeople = currentLineArray.length - 1;
			String ranker = currentLineArray[0];
		
			if( ! proposer.contains(ranker))  //avoid duplicates
			{
			    List<String> prefList = Arrays.asList(Arrays.copyOfRange(currentLineArray, 1, currentLineArray.length));
			    proposer.add(ranker);
			    proposerRanking.put(ranker, prefList);
			}
		}
		
		//RECEIVER
        while((currentLineString = fileReader2.readLine()) != null) 
        {
			currentLineArray = currentLineString.split(" ");
			int numberOfPeople = currentLineArray.length - 1;
			String ranker = currentLineArray[0];
			
			if( ! receiver.contains(ranker))
			{
			    List<String> prefList = Arrays.asList(Arrays.copyOfRange(currentLineArray, 1, currentLineArray.length));
			    receiver.add(ranker);
			    receiverRanking.put(ranker, prefList);
			}
		}

	} 
	catch (IOException e) 
	{
		e.printStackTrace();
	} 
		
	fileReader1.close();
	fileReader2.close();		
  }
	
	private static void randomInputGeneration()
	{
		
	}
	
	
	
	private static void prepareRankingList() 
	{		
		int receiverIndex = 1;		
		
		for(int i = 0; i <= receiver.size(); i++)
			for(int j = 0; j <= proposer.size(); j++)
				receiverRankingList[i][j] = 0;
		
		for(String eachReceiver : receiver)
		{
			int k = 1;
			List<String> receiverPreferences =  receiverRanking.get(eachReceiver);
			
			     //storing ASCII value of receiver in their ranking list at 0th position
			      receiverRankingList[receiverIndex][0] = ((int)eachReceiver.charAt(0));
					
			      for(String proposer : receiverPreferences)
			      {
					 receiverRankingList[receiverIndex][Integer.parseInt(proposer)] = k;
					 k++;
			      }
			     receiverIndex++;
		}
	}
	
	private static boolean checkStability() throws Exception
	{
		takeInputFromFile();
		prepareRankingList();
		
		 Map<String, String> invertedMatches = new TreeMap<String, String>();
		 for(Map.Entry<String, String> entry: matches.entrySet()) 
		     invertedMatches.put(entry.getValue(), entry.getKey());
		
		for(String eachProposer : proposer)
		{
			int index = 0;
			
			//stability check done only for those proposers who are matched
			if(matches.containsKey(eachProposer))
			{
				List<String> currentProposerPrefList = proposerRanking.get(eachProposer);

				//for each women in proposer's list such that this proposer prefers this women over the matched one
				while(!(currentProposerPrefList.get(index).equalsIgnoreCase(matches.get(eachProposer))))
				{
					String matchedProposer = invertedMatches.get(currentProposerPrefList.get(index));
					
					//if receiver prefers current proposer to the matched one - unstable matching!!
					if((receiverRankingList[(int)(currentProposerPrefList.get(index)).charAt(0) - 64][Integer.parseInt(eachProposer)] < receiverRankingList[(int)(currentProposerPrefList.get(index)).charAt(0) - 64][Integer.parseInt(matchedProposer)]) 
							&& (receiverRankingList[(int)(currentProposerPrefList.get(index)).charAt(0) - 64][Integer.parseInt(eachProposer)] != 0) )
						return false;
					else
					    index++;
				}
			}
		}
		
		return true;
	}
	
	private static void writeMatchingsToAFile() throws Exception
	{

		FileWriter fw = new FileWriter("Matchings.txt");
		BufferedWriter bw = new BufferedWriter(fw);

		try {
			bw.write(" Men  Women");
			bw.newLine();
			
			for(String eachReceiver : receiver)
			{
	            bw.append("  " + eachReceiver + "    " + matches.get(eachReceiver));
	            bw.newLine();
			}
			
		   } catch (IOException e) {e.printStackTrace();} 
		finally 
		{
			bw.close();
			fw.close();
		}
	}
}