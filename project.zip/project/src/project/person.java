package project;

import java.util.*;

public class person
{
	String name = null;
	List<String> prefList = new ArrayList<String>();
	List<Boolean> pointer = new ArrayList<Boolean>(Arrays.asList(new Boolean[mainGSAlgo.maxNoOfParticipants]));
	
	//constructor
	public person(String personName, List<String> preferences)
	{
		name = personName;
		prefList = preferences;
		
		//initially all proposers and receivers are available
		Collections.fill(pointer, Boolean.TRUE);
	}

}
