package project;

import javafx.application.*;
import javafx.event.*;
import javafx.scene.*;
import javafx.stage.*;

public class GUI extends Application
{
	public static void main(String args[])
	{
		launch(args);
	}
	
	@Override
	public void start(Stage primaryStage) throws Exception
	{
		
	}

}
