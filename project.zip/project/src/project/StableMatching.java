package project;

import java.util.*;
import java.io.*;
import java.io.IOException;


public class StableMatching 
{
	
	List<String> proposer = null;
	List<String> receiver = null;
	Map<String, List<String>> proposerRanking = null;
	Map<String, List<String>> receiverRanking = null;
	
	public static void main(String[] args) throws IOException 
	{		
		new StableMatching();
	}
	
	public StableMatching() throws IOException 
	{
		BufferedReader fileReader1 = null,fileReader2 = null;
		String choice = null;
		
		// initialialization
		proposer = new ArrayList<String>();
		receiver = new ArrayList<String>();
		proposerRanking = new HashMap<String, List<String>>();
		receiverRanking = new HashMap<String, List<String>>();
		
		try {
			String currentLineString = null;
			String[] currentLineArray = null;
			
		   //read proposer and receiver preferences from file
			do
			{	
				//input proposer from user
				System.out.println("Choose proposer : men or women?");
						
				BufferedReader br = new BufferedReader(new InputStreamReader (System.in));
				choice = br.readLine();	
				
			   if(choice.equalsIgnoreCase("men"))
			  {
			    fileReader1 = new BufferedReader(new FileReader("men preferences.txt"));
			    fileReader2 = new BufferedReader(new FileReader("women preferences.txt"));
			    break;
			  }
			  else if(choice.equalsIgnoreCase("women"))
			  {
				 fileReader2 = new BufferedReader(new FileReader("men preferences.txt"));
				 fileReader1 = new BufferedReader(new FileReader("women preferences.txt"));
				 break;
			  }
			  else
				  System.out.println("Invalid choice! Enter again!");
			   
			}while(!(choice.equalsIgnoreCase("men") || choice.equalsIgnoreCase("women")));
			
			// store these preferences in data structures
			
			//PROPOSER
			while((currentLineString = fileReader1.readLine()) != null) 
			{
				currentLineArray = currentLineString.split(" ");
				int numberOfPeople = currentLineArray.length - 1;
				String ranker = currentLineArray[0];
			
				List<String> prefList = Arrays.asList(Arrays.copyOfRange(currentLineArray, 1, currentLineArray.length));
				proposer.add(ranker);
				proposerRanking.put(ranker, prefList);
			}
			
			//RECEIVER
            while((currentLineString = fileReader2.readLine()) != null) 
            {
				currentLineArray = currentLineString.split(" ");
				int numberOfPeople = currentLineArray.length - 1;
				String ranker = currentLineArray[0];
				
				List<String> prefList = Arrays.asList(Arrays.copyOfRange(currentLineArray, 1, currentLineArray.length));
				receiver.add(ranker);
				receiverRanking.put(ranker, prefList);
			}

		} 
		catch (IOException e) 
		{
			e.printStackTrace();
		} 
		finally 
		{
			try {
					fileReader1.close();
					fileReader2.close();
					
					Map<String, String> matches =  new TreeMap<String, String>();
					matches = doMatching();
					
					// print matches
					for(Map.Entry<String, String> matching:matches.entrySet())
					{
			            System.out.println(matching.getKey() + " " + matching.getValue());
			        
					// ensure stability
			        // if(checkMatches(matches)){
			        //     System.out.println("Stable matching");
			        // } else {
			        //     System.out.println("Unstable matching");
			        // }
				    }
			   } 
			catch (IOException ex) 
			{
				ex.printStackTrace();
			}
		}
	}
	
	private Map<String, String> doMatching() 
	{
		
		Map<String, String> matches = new TreeMap<String, String>();
		
		// freeProposers is the list of all proposers who are not matched, initially contains all proposers
		List<String> freeProposers = new LinkedList<String>();
		freeProposers.addAll(proposer);
		
		// loop until no more free proposers
		while(!freeProposers.isEmpty()) 
		{
			String currentProposer = freeProposers.remove(0);  //stack functioning
			List<String> currentProposerPrefers = proposerRanking.get(currentProposer);
			
			for (String receiver : currentProposerPrefers) 
			{
				//for each receiver, obtain his/her preference list
				List<String> currentReceiverPrefList = receiverRanking.get(receiver);
				
				//System.out.println("Receiver = " + receiver);
				
				if(matches.get(receiver) == null) 
				{ 
					//this receiver is free (not matched) - match these two
	                matches.put(receiver, currentProposer);
	                System.out.println("* (" + receiver + ", " + currentProposer + " )");
	                
	                //delete all proposers after the matched one now
	                //from the position of current proposer in the receiver's preference list, delete all proposers after that (extended Gale Shapley)
	                currentReceiverPrefList = currentReceiverPrefList.subList(0, currentReceiverPrefList.indexOf(currentProposer));
	                //List<String> truncateddReceiverList = (receiverRanking.get(receiver)).subList(0,currentReceiverPrefList.indexOf(currentProposer));
	                receiverRanking.put(receiver, currentReceiverPrefList);
	                
	                System.out.println(receiver + "'s preference list now : " + currentReceiverPrefList);
	                //currentProposerPrefers.remove(receiver);
	                break;
	            } 
				else 
				{
					//System.exit(0);
	                String matchedProposer = matches.get(receiver);
	                List<String> currentReceiverRanking = receiverRanking.get(receiver);
	                
	                //simply match this receiver to the current proposer
	                if(currentReceiverRanking.contains(currentProposer))   //indicates that current proposer is preferred over the matched one
	                {
	                    matches.put(receiver, currentProposer);
	                    matches.remove(matchedProposer);
	                    
		                //delete all proposers after the matched one now
		                //from the position of current proposer in the receiver's preference list, delete all proposers after that (extended Gale Shapley)
	                    currentReceiverPrefList = currentReceiverPrefList.subList(0, currentReceiverPrefList.indexOf(currentProposer));
		                //List<String> truncateddReceiverList = (receiverRanking.get(receiver)).subList(0,currentReceiverPrefList.indexOf(currentProposer));
		                receiverRanking.put(receiver, currentReceiverPrefList);
	                    
	                    System.out.println(receiver + "'s preference list now : " + currentReceiverPrefList);
	                    freeProposers.add(matchedProposer);
	                    break;
	                }
	                else
	                {
	                	//System.exit(0);
	                	System.out.println(currentProposer + " not in truncated list");
	                	//freeProposers.add(currentProposer);
	                	
	                }
	            }
	        }
		}
		return matches;
	}
}
	