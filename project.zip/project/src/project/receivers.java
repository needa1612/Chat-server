package project;

import java.util.*;

public class receivers extends person 
{
	//constructor
	public receivers(String personName, List<String> preferences)
	{
		super(personName, preferences);
	}
	
	//getters and setters
	public String getName()
	{
		return super.name;
	}
	
	public List<String> getPrefList()
	{
		return super.prefList;
	}
	
	public List<Boolean> getPointer()
	{
		return super.pointer;
	}
	
	public Boolean getPointerValueAtThisPosition(int position)
	{
		return super.pointer.get(position);
	}
	
	public void setName(String proposerName)
	{
		super.name = proposerName;
	}
	
	public void setPrefList(List<String> prefList)
	{
		super.prefList = prefList;
	}
	
	public void setPointer(int position, Boolean value)
	{
		super.pointer.set(position, value);
	}
	
	
	public int getProposerPosition(String proposerName)
	{
		for(String eachProposer : prefList)
		{
			if(eachProposer.equalsIgnoreCase(proposerName))
				return prefList.indexOf(eachProposer);
		}
		//if receiver not found in receivers pref list
		return -1;
	}

	
}
