package project;

import java.util.*;
import java.util.Map.Entry;
import java.io.*;

public class mainGSAlgo 
{
	static ArrayList<proposers> proposerList;
	static ArrayList<receivers> receiverList;
	static ArrayList<String> listOfProposers;
	static ArrayList<String> listOfReceivers;
	static List<proposers> freeProposers;
	static Map<String, String> matches;
	
	static int globalFrameIncrementer;
	static int maxNoOfParticipants = 10;
	static ArrayList<frame> frames;
	
	//default constructor
	public mainGSAlgo()
	{		
		proposerList =  new ArrayList<proposers>();
		receiverList = new ArrayList<receivers>();
		freeProposers  = new LinkedList<proposers>();
		listOfProposers = new ArrayList<String>();
		listOfReceivers = new ArrayList<String>();
		matches = new HashMap<String, String>();
		
		globalFrameIncrementer = 0;
		frames = new ArrayList<frame>();
	}

	public static void main(String args[]) throws Exception
	{
//		doMatching();
//
//		// print matches
//		System.out.println("\n-----------------------------------------");
//		System.out.println("               MATCHINGS ");
//		System.out.println("-----------------------------------------");
//
//		if(receiverList.size() >= proposerList.size())
//		{	
//			for(receivers eachReceiver : receiverList)
//				System.out.println(eachReceiver.getName() + " " + matches.get(eachReceiver.getName()));
//		}
//		else
//		{
//			for(proposers eachProposer : proposerList)
//				System.out.println(eachProposer.getName() + " " + findKey(eachProposer.getName()));
//		}
//
//		System.out.println("-----------------------------------------\n");
//
//		//preparing ranking list for proposers
//		for(proposers eachProposer : proposerList)
//			eachProposer.prepareRankingList();
//
//		//check if matches made are stable
//		if(checkStability())
//			System.out.println("\nStable");
//		else
//			System.out.println("\nUnstable");
//
//		//write matchings to a file
//		writeMatchingsToAFile();
	}
	
	public static void takeInputFromFile(FileReader file) throws Exception
	{		
		BufferedReader fileReader = null;
		//taking input from file - read proposer and receiver preferences
		try {
			String currentLineString = null;
			String[] currentLineArray = null;
			fileReader = new BufferedReader(file);

			// store these preferences in data structures

			//PROPOSER
			while(!((currentLineString = fileReader.readLine()).equals(""))) 
			{
				currentLineArray = currentLineString.split(" ");
                List<String> prefList = Arrays.asList(Arrays.copyOfRange(currentLineArray, 1, currentLineArray.length));
				proposerList.add(new proposers(currentLineArray[0],prefList));
				listOfProposers.add(currentLineArray[0]);
			}

			//RECEIVER
			while((currentLineString = fileReader.readLine()) != null) 
			{
				currentLineArray = currentLineString.split(" ");
				List<String> prefList = Arrays.asList(Arrays.copyOfRange(currentLineArray, 1, currentLineArray.length));
				receiverList.add(new receivers(currentLineArray[0],prefList));
				listOfReceivers.add(currentLineArray[0]);
			}
			
			for(int i = 0 ; i < proposerList.size() ; i++)
				freeProposers.add(proposerList.get(i));
		} 
		catch (IOException e) 
		{
			e.printStackTrace();
		} 

		fileReader.close();		
	}
	
	
	//ASSUMPTION : this function always generates consistent input
	public static void randomInputGeneration(int noOfProposers, int noOfReceivers) throws Exception
	{
		Random rand = new Random();

		//preparing proposer preference list
		for(int i = 0; i < noOfProposers; i++)
		{
			int noOfPrefernces = rand.nextInt(noOfReceivers);
			List<String> preferences = new ArrayList<String>();

			for(int j = 0 ; j < noOfPrefernces ; j++)
			{
				String generatedReceiver = Character.toString((char)(rand.nextInt(noOfReceivers) + 65));
				if( ! (preferences.contains(generatedReceiver)))
					preferences.add(generatedReceiver);	
			}

			proposerList.add(new proposers(("" + (i+1)), preferences));
		}
		
		//preparing list of receivers
		for(int i = 0 ; i < noOfReceivers ; i++)
			listOfReceivers.add("" + (char)(i+65));

		//preparing receiver preference list
		for(String eachReceiver : listOfReceivers)
		{
			List<String> preferences = new ArrayList<String>();

			for(proposers eachProposer: proposerList)
			{
				if(eachProposer.getPrefList().contains(eachReceiver))
					preferences.add(eachProposer.getName());
			}

	        receiverList.add(new receivers(eachReceiver, preferences));

		}
		
		for(int i = 0 ; i < proposerList.size() ; i++)
			freeProposers.add(proposerList.get(i));
	}

	public static boolean consistentInputCheck()
	{
		int proposerPrefCount = 0 , receiverPrefCount = 0;

		for(proposers eachProposer : proposerList)
		{
			List<String> currentProposerPrefList = eachProposer.getPrefList();

			for(String receiver : currentProposerPrefList)
			{
			    proposerPrefCount++;
			    
				if((contains(receiver).getPrefList()).contains(eachProposer.getName())) ;
				else 
				   return false;
			}
		}

		for(receivers eachReceiver: receiverList)
		{
			List<String> currentReceiverPrefList = eachReceiver.getPrefList();
				receiverPrefCount += currentReceiverPrefList.size();
		}
		
		if(proposerPrefCount == receiverPrefCount)
			return true;
		else
			return false;
	}

	
	//return receiver object from receiver name
	public static receivers contains(String name)
	{
		for(receivers eachReceiver : receiverList)
		{
			if(eachReceiver.getName().equalsIgnoreCase(name))
				return eachReceiver;
		}
		//else no receiver with this name - return null
		return null;
		
	}
	
	
	//return proposer object from proposer name
	public static proposers getProposer(String proposerName)
	{
		for(proposers eachProposer : proposerList)
		{
			if(eachProposer.getName().equalsIgnoreCase(proposerName))
				return eachProposer;
		}
		//else no receiver with this name - return null
		return null;
		
	}
	
	public static void randomizeCurrentInput()
	{
		Random rand = new Random();
		freeProposers  = new LinkedList<proposers>();

		for( int i = 0; i < proposerList.size(); i++ )
		{
			int position = rand.nextInt(proposerList.size());

			//swap ith proposer with randomly generated proposer
			proposers tempProposer = proposerList.get(position);
			proposerList.set(position, proposerList.get(i));
			proposerList.set(i, tempProposer);
		}
		
		for(int i = 0 ; i < proposerList.size() ; i++)
			freeProposers.add(proposerList.get(i));
	}

	public static Map<String, String> doMatching()
	{
		// initially all proposers are available
		freeProposers.addAll(proposerList);

		// loop until no more free proposers
		while(!freeProposers.isEmpty()) 
		{			
			proposers currentProposer = freeProposers.remove(0);  //stack functioning
			List<String> currentProposerPrefers = currentProposer.getPrefList();
			
			/*int proposerListIndex = 0;
			while(!currentProposer.getPointerValueAtThisPosition(proposerListIndex))
			   proposerListIndex++;
			
			receivers receiverUnderConsideration = contains(currentProposer.getPrefList().get(proposerListIndex)); 
			int receiverListIndex =  receiverUnderConsideration.getProposerPosition(currentProposer.getName());*/
			
			//create frame object here and display it
			//createFrame(currentProposer.getName(), receiverUnderConsideration.getName(), proposerListIndex, receiverListIndex , "", "", "" );
                
			for (String receiver : currentProposerPrefers) 
			{
				receivers currentReceiver = contains(receiver);
				//System.out.println(currentProposer.getName() + ".pointer[" + currentProposer.getPrefList().indexOf(currentReceiver.getName()) + "] = " + currentProposer.getPointer().get(currentProposer.getPrefList().indexOf(currentReceiver.getName())));
				
				//make proposal only if receiver in preference list are still available (not deleted)
				if(currentProposer.getPointer().get(currentProposer.getPrefList().indexOf(currentReceiver.getName())))
				{	
					//System.out.println(currentProposer.getName() + " proposes " + receiver);
					
                    //proposal made : create new frame
					createFrame(currentProposer.getName(), receiver, currentProposer.getReceiverPosition(receiver), contains(receiver).getProposerPosition(currentProposer.getName()) , "", currentProposer.getName() + " proposes " + receiver + "\n", "" );

					//pointer set to false for the receiver currently being proposed
					currentProposer.getPointer().set(currentProposer.getReceiverPosition(receiver), false);				

					//once you find the required proposer in the receiverPrefList - match it!
					//System.out.println("Match: ( " + receiver + " , " + currentProposer.getName() + " )");
					
					//match made : frame creation needed!
					createFrame(currentProposer.getName(), receiver, currentProposer.getReceiverPosition(receiver),contains(receiver).getProposerPosition(currentProposer.getName()), "", "New match made \n", "Match : (" + currentProposer.getName() + " , " + receiver + " ) \n");
					
					
					if(matches.containsKey(receiver))
					//if(matches.containsValue(receiver))
					{
						freeProposers.add(getProposer(matches.get(receiver)));
						//System.out.println(matches.get(receiver)+ " becomes free now");
						
						//proposer gets free : create new frame
						createFrame(currentProposer.getName(), receiver, currentProposer.getReceiverPosition(receiver),contains(receiver).getProposerPosition(currentProposer.getName()), matches.get(receiver) + "\n", "Proposer " + matches.get(receiver) + " becomes free now \n" , "");
					}

					//put replaces already existing entries, if present
					matches.put(receiver, currentProposer.getName());	

					//for each receiver, obtain his/her preference list
					List<String> currentReceiverPrefList = currentReceiver.getPrefList();

					//delete proposers from receiverPrefList
					//for each proposer after the one who is proposing, delete this proposer from the receiver preference list
					System.out.println("");
					
					for(int i = currentReceiverPrefList.indexOf(currentProposer.getName()) ; i < currentReceiverPrefList.size() ; i++)
					{
						currentReceiver.getPointer().set(currentReceiver.getProposerPosition(currentProposer.getName()), false);
						setAllPointersAfterThisToFalse(currentReceiver, i, currentProposer);
						
						//System.out.println(currentReceiver.getName() + ".pointer[" + i + "] = " + currentReceiver.getPointerValueAtThisPosition(currentReceiver.getProposerPosition(currentProposer.getName())));
						
						//System.out.println("Receiver : " + currentReceiver.getPrefList().get(i));
						
						proposers proposerForDeletion = getProposer(currentReceiver.getPrefList().get(i));
						proposerForDeletion.getPointer().set((getProposer(currentReceiver.getPrefList().get(i)).getPrefList()).indexOf(receiver),false);
					
						//deletions on proposer side : create new frame
						createFrame(currentReceiver.getPrefList().get(i), currentReceiver.getName(), (getProposer(currentReceiver.getPrefList().get(i)).getPrefList()).indexOf(receiver), i, "", currentReceiver.getName() + " deleted from " + currentReceiver.getPrefList().get(i) + "'s preference list \n" ,"" );
						
						//System.out.println(currentReceiver.getPrefList().get(i) + ".pointer[" + (getProposer(currentReceiver.getPrefList().get(i)).getPrefList()).indexOf(receiver) + "] = " + currentProposer.getPointerValueAtThisPosition((getProposer(currentReceiver.getPrefList().get(i)).getPrefList()).indexOf(receiver)));
					
						//System.out.println(currentReceiver.getName() + "'s pointer array : " + currentReceiver.getPointer());
						//System.out.println(currentReceiverPrefList.get(i) + "'s pointer array : " + getProposer(currentReceiver.getPrefList().get(i)).getPointer());
					}

					break;
				}
				else;
			}
		}

		return matches;
	}
	
	public static String findKey(String receiver)
	{
		 for (Entry<String, String> entry : matches.entrySet())
		 {
		    if (Objects.equals(receiver, entry.getValue())) 
		       return entry.getKey();
		 }
		 return null;
		
	}
	
	public static void setAllPointersAfterThisToFalse(receivers currentReceiver , int position, proposers currentProposer)
	{
		for(int i = position; i < currentReceiver.getPointer().size(); i++)
		{
			currentReceiver.setPointer(i, Boolean.FALSE);
			
			//deletions being done on receiver side : create frame
			createFrame(currentProposer.getName(), currentReceiver.getName(), currentProposer.getReceiverPosition(currentReceiver.getName()), i,"", currentProposer.getName() + " deleted from " + currentReceiver.getName() + "'s preference list \n" ,"" );
		}
		
	}
	
	public static boolean checkStability() throws Exception
	{
		for(receivers eachReceiver : receiverList)
		{
			int i = 0;
			
			//System.out.println("Receiver : " + eachReceiver.getName());
			
			List<String> currentReceiverPreferences = eachReceiver.getPrefList();
			String matchedProposer = matches.get(eachReceiver.getName());
			
			//if receiver not matched to anyone, continue to next receiver
			//System.out.println(matchedProposer);
			if(matchedProposer == null)
				continue;
			
			//System.out.println(currentReceiverPreferences.get(i) + " compared to " + matchedProposer);
			
			while( ! (currentReceiverPreferences.get(i).equalsIgnoreCase(matchedProposer)))
			{
				List<Integer> rankingListForCurrentProposer = getProposer(currentReceiverPreferences.get(i)).getRankingList();
				String currentProposerMatchedTo = findKey(currentReceiverPreferences.get(i));
				
				//if current proposer not matched to anyone, move to next proposer in list
				if(currentProposerMatchedTo == null)
				{
					i++;
					continue;
				}
				 
				int indexOfEachReceiver = (int)(eachReceiver.getName()).charAt(0) - 65;
				int indexOfMatchedReceiver = (int)(currentProposerMatchedTo).charAt(0) - 65;
				
				//System.out.println(currentProposerMatchedTo + " <= " + eachReceiver.getName() + " ?");
				//System.out.println(indexOfMatchedReceiver + " <= " + indexOfEachReceiver + " ?");
				
				//obtain proposer whose ranking list is considered
				List<Integer> currentProposerRankingList = getProposer(currentReceiverPreferences.get(i)).getRankingList();
						
				if(currentProposerRankingList.get(indexOfMatchedReceiver) <= currentProposerRankingList.get(indexOfEachReceiver));
				else
					return false;
				
				i++;
			}
		}
		return true;
	}

	public static void writeMatchingsToAFile() throws Exception
	{

		FileWriter fw = new FileWriter("Matchings.txt");
		BufferedWriter bw = new BufferedWriter(fw);

		try {
			bw.write(" Men  Women");
			bw.newLine();

			for(receivers eachReceiver : receiverList)
			{
				bw.append("  " + eachReceiver.getName() + "    " + matches.get(eachReceiver.getName()));
				bw.newLine();
			}

		} catch (IOException e) {e.printStackTrace();} 
		finally 
		{
			bw.close();
			fw.close();
		}
	}

	//create frame - distinguish between circles and crosses
	public static void createFrame(String currentProposer, String currentReceiver, int posInProposerPreferences, int posInReceiverPreferences,  String freeProposer, String trace, String matches)
	{
		 frame tempFrame = new frame();
		    
		    if(globalFrameIncrementer > 0)
		    	tempFrame = frames.get(globalFrameIncrementer - 1);
		    	
		    tempFrame.prepareFrame(currentProposer, currentReceiver, posInProposerPreferences, posInReceiverPreferences , freeProposer, trace , matches );
			frames.add(globalFrameIncrementer,tempFrame) ;
			//tempFrame.displayFrame();
         globalFrameIncrementer++;
	}
	
}
